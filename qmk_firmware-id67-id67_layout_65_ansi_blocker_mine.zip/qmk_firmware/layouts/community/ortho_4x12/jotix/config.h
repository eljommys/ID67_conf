// jotix ortho_4x12_layout config.h

#define TAPPING_TOGGLE 2
#define TAPPING_TERM 175